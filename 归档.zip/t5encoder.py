from transformers import AutoTokenizer, T5EncoderModel
import torch
import json
import numpy as np

# 初始化模型和分词器
model_name = "t5-small"  # 可选: t5-base, t5-large, google/flan-t5-xl
path = '/t5-small'
model = T5EncoderModel.from_pretrained(path, torch_dtype=torch.bfloat16,device_map="cuda").cuda().eval()
tokenizer = AutoTokenizer.from_pretrained(path, use_fast=True,trust_remote_code=True)
# 输入文本处理
text = "Direction of Flow Field Movement:\nThe flow field moves from the top left to the bottom right.\n\nChange of the Center Position of the Convergence:\nThe center of the convergence moves from the top left to the bottom right.\n\nChanges in the distribution of the color locations:\nThe color distribution changes from a more uniform distribution to a more concentrated distribution towards the bottom right.\n\nFlow Pattern:\nThe flow pattern changes from a more uniform pattern to a more concentrated pattern towards the bottom right.\n\nThe location where the brightest areas appear:\nThe brightest areas appear towards the bottom right."
inputs = tokenizer(
    "convert text to vector: " + text,  # T5需要任务前缀
    return_tensors="pt",
    padding="max_length",
    max_length=32,
    truncation=True
).to(model.device)

with torch.no_grad():
    outputs = model(**inputs)

last_hidden_states = outputs.last_hidden_state
print("last_hidden_states.shape:",last_hidden_states.shape)
sentence_embedding = torch.mean(last_hidden_states, dim=1)
sentence_embedding = torch.nn.functional.normalize(sentence_embedding, p=2, dim=-1)
sentence_embedding = sentence_embedding.cpu()
print(f"向量维度: {sentence_embedding.shape}")
print(f"样例向量: {sentence_embedding[0, :5]}")  # 打印前5维验证


class T5Encoder:
    def __init__(self, model_name="t5-small", path='/home/t5-small/AI-ModelScope/t5-small'):
        self.model = T5EncoderModel.from_pretrained(path, torch_dtype=torch.bfloat16, device_map="cuda").cuda().eval()
        self.tokenizer = AutoTokenizer.from_pretrained(path, use_fast=True, trust_remote_code=True)

    def encode(self, text):
        inputs = self.tokenizer(
            "convert text to vector: " + text,  # T5需要任务前缀
            return_tensors="pt",
            padding="max_length",
            max_length=32,
            truncation=True
        ).to(self.model.device)

        with torch.no_grad():
            outputs = self.model(**inputs)
            last_hidden_states = outputs.last_hidden_state
            # print("last_hidden_states.shape:", last_hidden_states.shape)
            sentence_embedding = torch.mean(last_hidden_states, dim=1)
            sentence_embedding = torch.nn.functional.normalize(sentence_embedding, p=2, dim=-1)
            # 将 BFloat16 类型的张量转换为 Float32 类型
            sentence_embedding = sentence_embedding.to(torch.float32).cpu().numpy()
        return sentence_embedding


# 定义任务名称
task = "SEVIR"  # 你需要将 "your_task_name" 替换为实际的任务名称

# 读取 json 文件
file_path = f'./pictures/all_responses_{task}_video.json'
with open(file_path, 'r', encoding='utf-8') as f:
    data = json.load(f)


# 初始化 T5Encoder 类
t5_encoder = T5Encoder()

# 初始化一个空的列表来存储每个 item 生成的向量
vectors = []

# 遍历 json 文件中的每个 item
for item in data:
    # 获取 response 下的内容
    response = item.get('response', '')
    # 使用 encoder 生成向量
    vector = t5_encoder.encode(response)
    # 将向量添加到列表中
    vectors.append(vector.squeeze())

# 将列表中的向量组合成一个 numpy 数组
combined_vectors = np.stack(vectors, axis=0)

# 检查组合后的向量维度是否为 [800, 512]
assert combined_vectors.shape == (1200, 512), f"组合后的向量维度应为 [800, 512]，但实际为 {combined_vectors.shape}"

# 保存组合后的向量到 npy 文件
save_path = f'./pictures/{task}_combined_vectors.npy'
np.save(save_path, combined_vectors)

print(f"向量已成功保存到 {save_path} 文件中。")


file_path = f'./pictures/{task}_combined_vectors.npy'
loaded_vectors = np.load(file_path)

# 打印读取向量的维度
print(f"读取的向量维度为: {loaded_vectors.shape}")