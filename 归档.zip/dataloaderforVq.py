import h5py
import torch
import scipy.io
import numpy as np
import pickle

from openpyxl.chart.trendline import Trendline


def navier_stokesforVq(path, VectorPath,batch_size=16, T_in=10, T_out=10, type="1e-5", sub=1, reshape=[0, 3, 1, 2]):
    if type == "1e-3":
        ntrain = 1000
        neval = 200
        ntest = 200
        total = ntrain + neval + ntest
        f = h5py.File(path, "r")
        # 打开一个 HDF5 文件,r代表只读模式
        data = f['u'][..., 0:total]
        # 选取前面的所有维度，在数量上丛0到total
        print("dataset shape : ", data.shape)  # Print original shape of the data


        data = torch.tensor(data, dtype=torch.float32)
        data = data.permute(3, 1, 2, 0)  # The dimension of the data shape is [B, X, Y, T]

        # Traning data
        train_a = data[:ntrain, ::sub, ::sub, :T_in]
        # start:stop:step,::代表切片操作，这里省略了start和stop，以sub进行切片
        train_u = data[:ntrain, ::sub, ::sub, T_in:T_out + T_in]
        # Evaluation data
        eval_a = data[ntrain:ntrain + neval, ::sub, ::sub, :T_in]
        eval_u = data[ntrain:ntrain + neval, ::sub, ::sub, T_in:T_out + T_in]
        # Testing data
        test_a = data[neval:neval + ntest, ::sub, ::sub, :T_in]
        test_u = data[neval:neval + ntest, ::sub, ::sub, T_in:T_out + T_in]

        if reshape:
            train_a = train_a.permute(reshape)
            train_u = train_u.permute(reshape)
            eval_a = eval_a.permute(reshape)
            eval_u = eval_u.permute(reshape)
            test_a = test_a.permute(reshape)
            test_u = test_u.permute(reshape)

        print("Navier-Stokes (vis = 1e-3) Dataset has been loaded successfully!")
        print("X train shape:", train_a.shape, "Y train shape:", train_u.shape)
        print("X eval shape:", eval_a.shape, "Y eval shape:", eval_u.shape)
        print("X test shape:", test_a.shape, "Y test shape:", test_u.shape)
        train_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(train_a, train_u),
                                                   batch_size=batch_size, shuffle=True)
        eval_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(eval_a, eval_u), batch_size=batch_size,
                                                  shuffle=False)
        test_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(test_a, test_u), batch_size=batch_size,
                                                  shuffle=False)
    elif type == "1e-5":
        ntrain = 800
        neval = 100
        ntest = 200
        total = ntrain + neval + ntest
        f = scipy.io.loadmat(path)
        vectors = np.load(VectorPath)
        data = f['u'][..., 0:total]
        # 将数据按需加载为 PyTorch 张量，避免一次性加载
        # 自监督训练，无监督生成
        train_a = torch.tensor(data[:ntrain, ::sub, ::sub, :T_in].copy(), dtype=torch.float32)
        train_u = torch.tensor(data[:ntrain, ::sub, ::sub, :T_in].copy(), dtype=torch.float32)
        eval_a = torch.tensor(data[ntrain:ntrain + neval, ::sub, ::sub, :T_in].copy(), dtype=torch.float32)
        eval_u = torch.tensor(data[ntrain:ntrain + neval, ::sub, ::sub, :T_in].copy(),
                              dtype=torch.float32)
        generate_a = torch.tensor(data[:ntest, ::sub, ::sub, :T_in].copy(), dtype=torch.float32)
        generate_u = torch.tensor(data[:ntest, ::sub, ::sub, T_in:T_out + T_in].copy(),
                              dtype=torch.float32)
        vectors_train = torch.tensor(vectors[:ntrain,:], dtype=torch.float32)#[800,512]
        print("vectors train shape : ", vectors_train.shape)
        vectors_eval = torch.tensor(vectors[ntrain:ntrain + neval,:], dtype=torch.float32)#[800,512]
        print("vectors eval shape : ", vectors_eval.shape)
        vectors_generate = torch.tensor(vectors[:ntest, :], dtype=torch.float32)  # [800,512]
        print("vectors test shape : ", vectors_generate.shape)

        # 计算训练数据的均值和标准差
        mean = train_a.mean()
        std = train_a.std()

        # 归一化所有数据
        train_a = (train_a - mean) / std
        train_u = (train_u - mean) / std
        eval_a = (eval_a - mean) / std
        eval_u = (eval_u - mean) / std
        generate_a = (generate_a - mean) / std
        generate_u = (generate_u - mean) / std

        if reshape:
            train_a = train_a.permute(reshape)
            train_u = train_u.permute(reshape)
            eval_a = eval_a.permute(reshape)
            eval_u = eval_u.permute(reshape)
            generate_a = generate_a.permute(reshape)
            generate_u = generate_u.permute(reshape)

        train_a = train_a.unsqueeze(2)
        train_u = train_u.unsqueeze(2)
        eval_a = eval_a.unsqueeze(2)
        eval_u = eval_u.unsqueeze(2)
        generate_a = generate_a.unsqueeze(2)
        generate_u = generate_u.unsqueeze(2)

        b,t,c,h,w = train_a.shape
        # train_a = train_a.reshape(-1, c, h, w)
        # train_u = train_u.reshape(-1, c, h, w)
        # eval_a = eval_a.reshape(-1, c, h, w)
        # eval_u = eval_u.reshape(-1, c, h, w)
        # generate_a = generate_a.reshape(-1, c, h, w)
        # generate_u = generate_u.reshape(-1, c, h, w)

        print("Navier-Stokes (vis = 1e-5) Dataset has been loaded successfully!")
        print("X train shape:", train_a.shape, "Y train shape:", train_u.shape)
        print("X eval shape:", eval_a.shape, "Y eval shape:", eval_u.shape)
        print("X test shape:", generate_a.shape, "Y test shape:", generate_u.shape)
        train_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(train_a, train_u,vectors_train),
                                                   batch_size=batch_size, shuffle=True)
        eval_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(eval_a, eval_u,vectors_eval), batch_size=batch_size,
                                                  shuffle=False)
        generate_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(generate_a, generate_u,vectors_generate), batch_size=batch_size,
                                                  shuffle=False)

    else:
        print("The type is unclaimed. Data loading is failed.")
        return

    return train_loader, eval_loader, generate_loader, ntrain,neval,ntest

def b1_fds_loaderforVq(path, batch_size=16, T_in=15, T_out=5, sub=1, reshape=False):
    # 加载数据
    data = np.load(path)
    print("Dataset shape:", data.shape)  # 打印原始数据形状

    data = torch.tensor(data, dtype=torch.float32)
    data = data.permute(0, 1, 2, 3, 4)  # 确保数据顺序为 [Batch, Time Steps, Channels, Height, Width]

    # 数据划分
    ntrain = 200
    neval = 50
    ngenerate = 40
    total = ntrain + neval + ngenerate

    # 训练数据
    train_a =data[:ntrain, :T_in, ::sub, ::sub, ::sub]
    train_u = data[:ntrain, :T_in,::sub, ::sub, ::sub]

    # 验证数据
    eval_a = data[ntrain:ntrain + neval, :T_in, ::sub, ::sub, ::sub]
    eval_u = data[ntrain:ntrain + neval, :T_in,::sub, ::sub, ::sub]

    # 测试数据
    generate_a = data[:ngenerate, :T_in, ::sub, ::sub, ::sub]
    generate_u = data[:ngenerate,T_in:T_out + T_in,::sub, ::sub, ::sub]

    b, t, c, h, w = train_a.shape
    # train_a = train_a.reshape(-1, c, h, w)
    # train_u = train_u.reshape(-1, c, h, w)
    # eval_a = eval_a.reshape(-1, c, h, w)
    # eval_u = eval_u.reshape(-1, c, h, w)
    # generate_a = generate_a.reshape(-1, c, h, w)
    # generate_u = generate_u.reshape(-1, c, h, w)
    # 计算训练数据的均值和标准差
    mean = train_a.mean()
    std = train_a.std()

    # 归一化所有数据
    train_a = (train_a - mean) / std
    train_u = (train_u - mean) / std
    eval_a = (eval_a - mean) / std
    eval_u = (eval_u - mean) / std
    generate_a = (generate_a - mean) / std
    generate_u = (generate_u - mean) / std

    print("B1-FDS Dataset has been loaded successfully!")
    print("X train shape:", train_a.shape, "Y train shape:", train_u.shape)
    print("X eval shape:", eval_a.shape, "Y eval shape:", eval_u.shape)
    print("X test shape:", generate_a.shape, "Y test shape:", generate_u.shape)

    # 使用 DataLoader 创建数据迭代器
    train_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(train_a, train_u), batch_size=batch_size,
                                               shuffle=True)
    eval_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(eval_a, eval_u), batch_size=batch_size,
                                              shuffle=False)
    test_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(generate_a, generate_u), batch_size=batch_size,
                                              shuffle=False)

    return train_loader, eval_loader, test_loader, ntrain, neval, ngenerate

def a58_fds_loaderforVq(path, batch_size=3, T_in=10, T_out=10, sub=1, reshape=False):
    # 加载数据
    data = np.load(path)
    print("Dataset shape:", data.shape)  # 打印原始数据形状

    data = torch.tensor(data, dtype=torch.float32)
    data = data.permute(0, 1, 2, 3, 4)  # 确保数据顺序为 [Batch, Time Steps, Channels, Height, Width]
    # 数据划分
    ntrain = 200
    neval = 40
    ngenerate =40
    total = ntrain + neval + ngenerate

    # 训练数据
    train_a =data[:ntrain, :T_in, ::sub, ::sub, ::sub]
    train_u = data[:ntrain, :T_in,::sub, ::sub, ::sub]

    # 验证数据
    eval_a = data[ntrain:ntrain + neval, :T_in, ::sub, ::sub, ::sub]
    eval_u = data[ntrain:ntrain + neval, :T_in,::sub, ::sub, ::sub]

    # indices = np.linspace(0, ntrain-1, ngenerate, dtype=int)
    # # 测试数据
    # generate_a = data[indices, :T_in, ::sub, ::sub, ::sub]
    # generate_u = data[indices,T_in:T_out + T_in,::sub, ::sub, ::sub]
    generate_a = data[:ngenerate, :T_in, ::sub, ::sub, ::sub]
    generate_u = data[:ngenerate,T_in:T_out + T_in,::sub, ::sub, ::sub]

    b, t, c, h, w = train_a.shape
    train_a = train_a.reshape(-1, c, h, w)
    train_u = train_u.reshape(-1, c, h, w)
    eval_a = eval_a.reshape(-1, c, h, w)
    eval_u = eval_u.reshape(-1, c, h, w)
    generate_a = generate_a.reshape(-1, c, h, w)
    generate_u = generate_u.reshape(-1, c, h, w)

    # 计算训练数据的均值和标准差
    mean = train_a.mean()
    std = train_a.std()

    # 归一化所有数据
    train_a = (train_a - mean) / std
    train_u = (train_u - mean) / std
    eval_a = (eval_a - mean) / std
    eval_u = (eval_u - mean) / std
    generate_a = (generate_a - mean) / std
    generate_u = (generate_u - mean) / std

    print("B1-FDS Dataset has been loaded successfully!")
    print("X train shape:", train_a.shape, "Y train shape:", train_u.shape)
    print("X eval shape:", eval_a.shape, "Y eval shape:", eval_u.shape)
    print("X test shape:", generate_a.shape, "Y test shape:", generate_u.shape)

    # 使用 DataLoader 创建数据迭代器
    train_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(train_a, train_u), batch_size=batch_size,
                                               shuffle=True)
    eval_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(eval_a, eval_u), batch_size=batch_size,
                                              shuffle=False)
    test_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(generate_a, generate_u), batch_size=batch_size,
                                              shuffle=False)

    return train_loader, eval_loader, test_loader, ntrain, neval, ngenerate


def WeatherBenchforVq(train_path,eval_path,test_path,VectorPath,batch_size =10 ,T_in=10, T_out=10, sub=1, reshape=False):
    # 加载数据
    ntrain = 2100
    neval =200
    ntest = 200

    with open(train_path, "rb") as trainfile:
        traindata = pickle.load(trainfile)
    with open(eval_path, "rb") as evalfile:
        evaldata = pickle.load(evalfile)
    with open(test_path, "rb") as testfile:
        testdata = pickle.load(testfile)
    vectors = np.load(VectorPath)
    # 将 x, y, context 分别取出并命名
    train_a = traindata["x"]  # 形状: (2300, 12, 2048, 1)
    print(f"train_a 的维度是: {train_a.shape}")

    # 将 x, y, context 分别取出并命名
    eval_a = traindata["x"]  # 形状: (329, 12, 2048, 1)

    # 将 x, y, context 分别取出并命名
    generate_a = traindata["x"]  # 形状: (657, 12, 2048, 1)
    generate_u = traindata["y"]

    h, w = 32, 64
    train_a = train_a.transpose(0, 1, 3, 2)  # (b,t,c,h*w)
    train_a = train_a.reshape(train_a.shape[0], train_a.shape[1], train_a.shape[2], h, w)  # (b, t, c, h, w)
    train_a = train_a[:2100, 2:12, :, :, :]

    train_u = train_a


    eval_a = eval_a.transpose(0, 1, 3, 2)  # (b,t,c,h*w)
    eval_a = eval_a.reshape(eval_a.shape[0], eval_a.shape[1], eval_a.shape[2], h, w)  # (b, t, c, h, w)
    eval_a = eval_a[2100:2300, 2:12, :, :, :]

    eval_u = eval_a

    generate_a = generate_a.transpose(0, 1, 3, 2)  # (b,t,c,h*w)
    generate_a = generate_a.reshape(generate_a.shape[0], generate_a.shape[1], generate_a.shape[2], h, w)  # (b, t, c, h, w)
    generate_a = generate_a[:200, 2:12, :, :, :]

    # generate_u = generate_a
    generate_u = generate_u.transpose(0, 1, 3, 2)  # (b,t,c,h*w)
    generate_u = generate_u.reshape(generate_u.shape[0], generate_u.shape[1], generate_u.shape[2], h,
                                    w)  # (b, t, c, h, w)
    generate_u = generate_u[:200, :10, :, :, :]



    # train_a = train_a.reshape(-1, 1, h, w)
    # train_u = train_u.reshape(-1, 1, h, w)
    # eval_a = eval_a.reshape(-1, 1, h, w)
    # eval_u = eval_u.reshape(-1, 1, h, w)
    # generate_a = generate_a.reshape(-1, 1, h, w)
    # generate_u = generate_u.reshape(-1, 1, h, w)

    vectors_train = torch.tensor(vectors[:ntrain, :], dtype=torch.float32)  # [800,512]
    print("vectors train shape : ", vectors_train.shape)
    vectors_eval = torch.tensor(vectors[ntrain:ntrain + neval, :], dtype=torch.float32)  # [800,512]
    print("vectors eval shape : ", vectors_eval.shape)
    vectors_generate = torch.tensor(vectors[:ntest, :], dtype=torch.float32)  # [800,512]
    print("vectors test shape : ", vectors_generate.shape)


    # 计算训练数据的均值和标准差
    mean = train_a.mean()
    std = train_a.std()

    # 归一化所有数据
    train_a = (train_a - mean) / std
    train_u = (train_u - mean) / std
    eval_a = (eval_a - mean) / std
    eval_u = (eval_u - mean) / std
    generate_a = (generate_a - mean) / std
    generate_u = (generate_u - mean) / std

    ntrain = train_a.shape[0]
    neval = eval_a.shape[0]
    ntest = generate_a.shape[0]

    print("B1-FDS Dataset has been loaded successfully!")
    print("X train shape:", train_a.shape, "Y train shape:", train_u.shape)
    print("X eval shape:", eval_a.shape, "Y eval shape:", eval_u.shape)
    print("X test shape:", generate_a.shape, "Y test shape:", generate_u.shape)

    train_a = torch.tensor(train_a, dtype=torch.float32)
    train_u = torch.tensor(train_u, dtype=torch.float32)
    eval_a = torch.tensor(eval_a, dtype=torch.float32)
    eval_u = torch.tensor(eval_u, dtype=torch.float32)
    generate_a = torch.tensor(generate_a, dtype=torch.float32)
    generate_u = torch.tensor(generate_u, dtype=torch.float32)
    #
    # 使用 DataLoader 创建数据迭代器
    train_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(train_a, train_u, vectors_train),
                                               batch_size=batch_size, shuffle=True)
    eval_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(eval_a, eval_u, vectors_eval),
                                              batch_size=batch_size,
                                              shuffle=False)
    generate_loader = torch.utils.data.DataLoader(
        torch.utils.data.TensorDataset(generate_a, generate_u, vectors_generate), batch_size=batch_size,
        shuffle=False)

    return train_loader, eval_loader, generate_loader, ntrain, neval, ntest

def sevir_loadforVq(path,VectorPath, batch_size=20, T_in=10, T_out=10, sub=1, reshape=False):  # 原本batch_size为20
    ntrain = 1000
    neval = 100
    ntest = 200
    total = ntrain + neval + ntest
    sevir_data = np.load(path)
    print("dataset shape : ", sevir_data.shape)
    # sevir_data = torch.tensor(sevir_data,dtype=torch.float32)
    vectors = np.load(VectorPath)
    # 将数据按需加载为 PyTorch 张量，避免一次性加载
    train_a = torch.tensor(sevir_data[:ntrain, :T_in, :, :,:].copy(), dtype=torch.float32)
    train_u = torch.tensor(sevir_data[:ntrain, :T_in, :, :, :].copy(), dtype=torch.float32)

    eval_a = torch.tensor(sevir_data[ntrain:ntrain + neval, :T_in, :, :,:].copy(), dtype=torch.float32)
    eval_u = torch.tensor(sevir_data[ntrain:ntrain + neval, :T_in, :, :, :].copy(),dtype=torch.float32)


    generate_a = torch.tensor(sevir_data[:ntest, :T_in, :, :,:].copy(), dtype=torch.float32)
    generate_u = torch.tensor(sevir_data[:ntest, T_in:T_in+T_out, :, :,:].copy(), dtype=torch.float32)
    vectors_train = torch.tensor(vectors[:ntrain, :], dtype=torch.float32)  # [800,512]
    print("vectors train shape : ", vectors_train.shape)
    vectors_eval = torch.tensor(vectors[ntrain:ntrain + neval, :], dtype=torch.float32)  # [800,512]
    print("vectors eval shape : ", vectors_eval.shape)
    vectors_generate = torch.tensor(vectors[:ntest, :], dtype=torch.float32)  # [800,512]
    print("vectors test shape : ", vectors_generate.shape)
    # 计算训练数据的均值和标准差
    mean = train_a.mean()
    std = train_a.std()

    # 归一化所有数据
    train_a = (train_a - mean) / std
    train_u = (train_u - mean) / std
    eval_a = (eval_a - mean) / std
    eval_u = (eval_u - mean) / std
    generate_a = (generate_a - mean) / std
    generate_u = (generate_u - mean) / std

    # if reshape:
    #     train_a = train_a.permute(reshape)
    #     train_u = train_u.permute(reshape)
    #     eval_a = eval_a.permute(reshape)
    #     eval_u = eval_u.permute(reshape)
    #     test_a = test_a.permute(reshape)
    #     test_u = test_u.permute(reshape)

    # train_a = train_a.unsqueeze(2)
    # train_u = train_u.unsqueeze(2)
    # eval_a = eval_a.unsqueeze(2)
    # eval_u = eval_u.unsqueeze(2)
    # generate_a = generate_a.unsqueeze(2)
    # generate_u = generate_u.unsqueeze(2)
    print("SEVIR Dataset has been loaded successfully!")
    print("X train shape:", train_a.shape, "Y train shape:", train_u.shape)
    print("X eval shape:", eval_a.shape, "Y eval shape:", eval_u.shape)
    print("X test shape:", generate_a.shape, "Y test shape:", generate_u.shape)

    train_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(train_a, train_u, vectors_train),
                                               batch_size=batch_size, shuffle=True)
    eval_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(eval_a, eval_u, vectors_eval),
                                              batch_size=batch_size,
                                              shuffle=False)
    generate_loader = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(generate_a, generate_u, vectors_generate), batch_size=batch_size,
        shuffle=False)

    return train_loader, eval_loader, generate_loader, ntrain, neval, ntest