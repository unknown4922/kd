import torch
import torch.nn as nn
import random
import torch.optim as optim
import torchvision
from torch.utils.data import DataLoader
import numpy as np
from dataloaderforVq import *
from utils import Adam
from vqvae_gen_model import BeamVQ
import matplotlib.pyplot as plt
from timeit import default_timer
import torchvision.transforms.functional as F
from pytorch_msssim import ssim, ms_ssim, SSIM, MS_SSIM
from baseline.vit2 import VisionTransformer
from baseline.fourcastnet import  Afno_net
from baseline.FNO_2d import FNO2d4fds
from baseline.ResNet import ResNet4fds
from baseline.UNet import U_net4fds
from baseline.ConvLSTM import CLSTM4fds
from baseline.UNO_2d import UNO4fds
from baseline.CNO import CNO4fds
from tqdm import tqdm
import os
seed = 42
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
set_seed(seed)

torch.cuda.empty_cache()
MSE_loss = torch.nn.MSELoss()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

task = 'SEVIR'
modelname = 'vqvae-mlp0.2'
top_k_numset = 3

if task == 'ns1e-5':
    batch_size = 8
    T_in = 10
    T_out = 10
    data_path = "./dataset/NavierStokes_V1e-5_N1200_T20.mat"
    VectorPath = "./pictures/ns1e-5_combined_vectors.npy"
    train_loader, eval_loader, test_loader, ntrain, neval, ngenerate = navier_stokesforVq(data_path,VectorPath,
                                                                                       batch_size=batch_size,
                                                                                       T_in=T_in,
                                                                                       T_out=T_out,
                                                                                       type = "1e-5",
                                                                                       reshape=[0, 3, 1, 2])
elif task == 'a5_fds':
    batch_size = 3
    T_in = 10
    T_out = 10
    data_path = "../dataset/a5_fds.npy"
    train_loader, eval_loader, test_loader, ntrain, neval, ngenerate = a58_fds_loaderforVq(data_path, batch_size=batch_size,T_in=T_in, T_out=T_out)
elif task == 'a8_fds':
    batch_size = 3
    T_in = 10
    T_out = 10
    data_path = "../dataset/a8_fds.npy"
    train_loader, eval_loader, test_loader, ntrain, neval, ngenerate = a58_fds_loaderforVq(data_path, batch_size=batch_size,T_in=T_in, T_out=T_out)
elif task == 'b1_fds':
    batch_size = 3
    T_in = 10
    T_out = 10
    data_path = "../dataset/b1_fds.npy"
    train_loader, eval_loader, test_loader, ntrain, neval, ngenerate = b1_fds_loaderforVq(data_path, batch_size=batch_size,T_in=T_in, T_out=T_out)
elif task == 'WeatherBench':
    batch_size = 10
    T_in = 10
    T_out = 10
    train_path = "./dataset/trn.pkl"
    eval_path = "./dataset/val.pkl"
    test_path = "./dataset/test.pkl"
    VectorPath = "./pictures/WeatherBench_combined_vectors.npy"
    train_loader, eval_loader, test_loader, ntrain, neval, ngenerate = WeatherBenchforVq(train_path,eval_path,test_path,VectorPath,10,10,10,sub=1, reshape=False)
elif task =='SEVIR':
    batch_size = 10
    T_in = 10
    T_out = 10
    data_path = "./dataset/SEVIR_ir069.npy"
    VectorPath = "./pictures/SEVIR_combined_vectors.npy"
    train_loader, eval_loader, test_loader, ntrain, neval, ngenerate = sevir_loadforVq(data_path,VectorPath , 10, 10,
                                                                                         10, sub=1, reshape=False)

model = BeamVQ(in_channel=1,res_units=64,res_layers=1,embedding_nums=1024,embedding_dim=512,top_k=top_k_numset-1,complete=True).to(device)
learning_rate = 0.001
scheduler_step = 25
# 定义学习率调度器的步长为 100 次。每经过 scheduler_step 次训练后，学习率将按照 scheduler_gamma 设置进行调整。
scheduler_gamma = 0.5
# 设置学习率调度器的衰减因子为 0.5。每 scheduler_step 次训练后，学习率将乘以这个因子。
# Define optimizer and loss function
optimizer = Adam(model.parameters(), lr=learning_rate, weight_decay=1e-4)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=scheduler_step, gamma=scheduler_gamma)
# 定义了一个学习率调度器 StepLR，它会在每 scheduler_step 次训练后，将当前学习率乘以 scheduler_gamma（即衰减到原来的 50%）

criterion = nn.MSELoss()
def train(model, loader, optimizer, criterion,batch_size):
    model.train()
    total_loss = 0

    for inputs, targets,vectors in loader:
        inputs, targets = inputs.to(device), targets.to(device)
        b,t,c,h,w = inputs.shape
        inputs = inputs.view(b*t,c,h,w)
        targets = targets.view(b*t,c,h,w)
        vectors = vectors.to(device)
        # print(inputs.shape, targets.shape)
        # print("vectors.shape:", vectors.shape)
        optimizer.zero_grad()
        pred, top_k_features, vq_loss = model(inputs,vectors)
        loss = MSE_loss(pred, targets)

        loss.backward()
        optimizer.step()

        total_loss += loss.item()
    return total_loss / len(loader)  # Return average loss per sample

def evaluate(model, loader, criterion,num,batch_size):
    model.eval()
    total_loss = 0
    num_batches2 = 0  # Counter to track number of batches
    with torch.no_grad():
        for inputs, targets, vectors in loader:
            inputs, targets = inputs.to(device), targets.to(device)
            vectors = vectors.to(device)
            b, t, c, h, w = inputs.shape
            inputs = inputs.view(b * t, c, h, w)
            targets = targets.view(b * t, c, h, w)
            pred, top_k_features, vq_loss = model(inputs,vectors)
            loss = MSE_loss(pred, targets)

            total_loss += loss.item()

    return total_loss / len(loader) # Return average loss per sample

# 训练
def generate(model, loader, criterion, num, batch_size,top_k_num):
    model.eval()
    total_loss = 0
    num_batches2 = 0  # Counter to track number of batches
    top_k_features_list = [[] for _ in range(top_k_num)]  # Initialize a list for top_k_features (5 elements)
    top_k_features_list_target = [[] for _ in range(top_k_num)]
    with torch.no_grad():
        for inputs, targets,vectors in loader:
            inputs, targets = inputs.to(device), targets.to(device)
            vectors = vectors.to(device)
            b, t, c, h, w = inputs.shape
            inputs = inputs.view(b * t, c, h, w)
            targets = targets.view(b * t, c, h, w)
            # original_xx = inputs.cpu().numpy()
            # Get model predictions and features
            pred, top_k_features, vq_loss = model(inputs,vectors)
            loss = MSE_loss(pred, inputs)
            total_loss += loss.item()
            pred2,top_k_features_targets,vq_loss_targets = model(targets,vectors)
            # Save inputs, true targets, and predictions for later analysis
            # inputs_list.append(original_xx)
            # trues_list.append(targets.cpu().numpy())
            # preds_list.append(pred.cpu().numpy())
            # pred插入
            top_k_features.insert(0, pred)
            top_k_features_targets.insert(0, pred2)
            # Accumulate top_k_features
            for i in range(top_k_num):
                top_k_features_list[i].append(top_k_features[i].cpu().numpy())
                top_k_features_list_target[i].append(top_k_features_targets[i].cpu().numpy())
            num_batches2 += 1

    # Concatenate all batches of top_k_features
    top_k_features_concatenated = [torch.cat([torch.tensor(f).to(device) for f in top_k_features_list[i]], dim=0)
                                   for i in range(top_k_num)]
    top_k_features_concatenated_target = [torch.cat([torch.tensor(f).to(device) for f in top_k_features_list_target[i]], dim=0)
                                   for i in range(top_k_num)]
    # Calculate average loss per sample
    average_loss = total_loss / num_batches2
    return top_k_features_concatenated,top_k_features_concatenated_target,average_loss  # Return the average loss and concatenated features


# # Training loop
num_epochs = 300
min_loss =100000
currentepoch = 0
save_path = f'./ckpt/{modelname}_ckpt_{task}.pth'
# for epoch in range(num_epochs):
#     t1 = default_timer()
#     train_loss = train(model, train_loader, optimizer, criterion,batch_size)
#     val_loss = evaluate(model, eval_loader, criterion,neval,batch_size)
#     if train_loss< min_loss:
#         min_loss = train_loss########
#         currentepoch = epoch
#         torch.save(model.state_dict(), save_path)
#     scheduler.step()
#     t2 = default_timer()
#     time = t2-t1
#     print(f'Epoch {epoch + 1}/{num_epochs}, Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}')
#     print(f'Epoch {epoch+1 }/{num_epochs} , Time Consuming:{time:.4f}s')

print("第：",currentepoch+1," 个周期训练参数被加载至测试集")
best_check = torch.load(save_path, weights_only=True)
if 'state_dict' in best_check:
    model.load_state_dict(best_check['state_dict'])
    print("最佳参数已加载1")
else:
    model.load_state_dict(best_check)
    print("最佳参数已加载2")

inputs_list = []
trues_list = []
preds_list = []


# Evaluate on test set
top_k_features_concatenated,top_k_features_concatenated_target,genloss = generate(model, test_loader, criterion,ngenerate,batch_size,top_k_num=top_k_numset)
print("生成损失为：",genloss)
print(len(top_k_features_concatenated))
print(top_k_features_concatenated[0].shape)
data1 = torch.cat(top_k_features_concatenated, dim=0)
target1 = torch.cat(top_k_features_concatenated_target, dim=0)
Augmented_sample = data1.view(-1,T_in, 1,192,192)
Augmented_target = target1.view(-1,T_out, 1,192, 192)
print(Augmented_sample.shape)

if Augmented_sample.is_cuda:
    print("Augmented_sample已转移至cpu")
    Augmented_sample = Augmented_sample.cpu()

if Augmented_target.is_cuda:
    print("Augmented_target已转移至cpu")
    Augmented_target = Augmented_target.cpu()

if isinstance(Augmented_sample, torch.Tensor):
    Augmented_sample_np = Augmented_sample.cpu().numpy()  # 确保在CPU上并转换为numpy数组
    np.save(f'./result/rebuildnpy/{task}_{modelname}_Augmented_sample.npy', Augmented_sample_np)
    print("已成功保存Augmented_sample为npy文件")

# 将Augmented_target转换为numpy数组并保存为npy文件
if isinstance(Augmented_target, torch.Tensor):
    Augmented_target_np = Augmented_target.cpu().numpy()  # 确保在CPU上并转换为numpy数组
    np.save(f'./result/rebuildnpy/{task}_{modelname}_Augmented_target.npy', Augmented_target_np)
    print("已成功保存Augmented_target为npy文件")
#####################################################
sub =1

# # ns方程
# ntrain = 1000
# neval = 100
# ntest = 100
# total = ntrain + neval + ntest
#
# f = scipy.io.loadmat(data_path)
# data = f['u'][..., 0:total]
# train_a = torch.tensor(data[:ntrain, ::sub, ::sub, :T_in].copy(), dtype=torch.float32)
# train_u = torch.tensor(data[:ntrain, ::sub, ::sub, T_in:T_out + T_in].copy(), dtype=torch.float32)
# eval_a = torch.tensor(data[ntrain:ntrain + neval, ::sub, ::sub, :T_in].copy(), dtype=torch.float32)
# eval_u = torch.tensor(data[ntrain:ntrain + neval, ::sub, ::sub, T_in:T_out + T_in].copy(),
#                               dtype=torch.float32)
# test_a = torch.tensor(data[ntrain+neval:neval + ntest+ntrain, ::sub, ::sub, :T_in].copy(), dtype=torch.float32)
# test_u = torch.tensor(data[ntrain+neval:neval + ntest+ntrain, ::sub, ::sub, T_in:T_out + T_in].copy(),
#                               dtype=torch.float32)
#
#
#
# train_a = train_a.permute([0,3,1,2])
# train_u = train_u.permute([0,3,1,2])
# eval_a = eval_a.permute([0,3,1,2])
# eval_u = eval_u.permute([0,3,1,2])
# test_a = test_a.permute([0,3,1,2])
# test_u = test_u.permute([0,3,1,2])
#
#
# train_a = train_a.unsqueeze(2)
# train_u = train_u.unsqueeze(2)
# eval_a = eval_a.unsqueeze(2)
# eval_u = eval_u.unsqueeze(2)
# test_a = test_a.unsqueeze(2)
# test_u = test_u.unsqueeze(2)
#
#
#
# # dup_a = torch.tensor(data[:200, ::sub, ::sub, :T_in].copy(), dtype=torch.float32)
# # dup_u = torch.tensor(data[:200, ::sub, ::sub, T_in:T_out + T_in].copy(),
# #                               dtype=torch.float32)
# # dup_a = dup_a.permute([0,3,1,2])
# # dup_u = dup_u.permute([0,3,1,2])
# # dup_a = dup_a.unsqueeze(2)
# # dup_u = dup_u.unsqueeze(2)
# # duplicated_tensor_a = torch.cat([dup_a, dup_a, dup_a], dim=0)
# # duplicated_tensor_u = torch.cat([dup_u, dup_u, dup_u], dim=0)
# # train_a  = torch.cat((train_a, duplicated_tensor_a), dim=0)
# # train_u = torch.cat((train_u, duplicated_tensor_u), dim=0)
# # print("dupilacated loaded")
# # 加噪验证
# x = train_a[:200, :, :, :, :]
# y = train_u[:200, :, :, :, :]
# # 定义噪声参数
# num_copies = 3
# max_strength = x.std() * 0.8  # 基于数据标准差动态调整
# print("max_strength:",max_strength)
# expanded_x = x.repeat(num_copies, 1, 1, 1, 1)  # [600, 10, 1, 192, 192]
# expanded_y = y.repeat(num_copies, 1, 1, 1, 1)  # [600, 10, 1, 192, 192]
# low_ratio = 0.2
# mid_ratio = 0.5
# high_ratio = 0.8
# strengths = torch.cat([
#     torch.full((200, 1), max_strength * low_ratio),
#     torch.full((200, 1), max_strength * mid_ratio),
#     torch.full((200, 1), max_strength * high_ratio),
# ]).view(-1, 1, 1, 1, 1)
# # 添加噪声
# noisex = torch.randn_like(expanded_x)
# noisy_data_x = expanded_x + strengths * noisex
# noisy_data_x = noisy_data_x.clone().detach()
# noisey = torch.randn_like(expanded_y)
# noisy_data_y = expanded_y + strengths * noisex
# noisy_data_y = noisy_data_y.clone().detach()
#
# train_a  = torch.cat((train_a, noisy_data_x), dim=0)
# train_u = torch.cat((train_u, noisy_data_y), dim=0)
# print("Noise loaded")
#
# # train_a  = torch.cat((train_a, Augmented_sample), dim=0)
# # train_u = torch.cat((train_u, Augmented_target), dim=0)
#
# # 计算训练数据的均值和标准差
# mean = train_a.mean()
# std = train_a.std()
#
# # 归一化所有数据
# train_a = (train_a - mean) / std
# train_u = (train_u - mean) / std
# eval_a = (eval_a - mean) / std
# eval_u = (eval_u - mean) / std
# test_a = (test_a - mean) / std
# test_u = (test_u - mean) / std
# print("Navier-Stokes (vis = 1e-5) Dataset has been loaded successfully!")
# print("X train shape:", train_a.shape, "Y train shape:", train_u.shape)
# print("X eval shape:", eval_a.shape, "Y eval shape:", eval_u.shape)
# print("X test shape:", test_a.shape, "Y test shape:", test_u.shape)
# train_loader2 = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(train_a, train_u),
#                                                    batch_size=batch_size, shuffle=True)
# eval_loader2 = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(eval_a, eval_u), batch_size=batch_size,
#                                                   shuffle=False)
# test_loader2 = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(test_a, test_u), batch_size=batch_size,
#                                                   shuffle=False)
#######

###############################
# WeatherBench
# with open(train_path, "rb") as trainfile:
#     traindata = pickle.load(trainfile)
# with open(eval_path, "rb") as evalfile:
#     evaldata = pickle.load(evalfile)
# with open(test_path, "rb") as testfile:
#     testdata = pickle.load(testfile)
#
# # 将 x, y, context 分别取出并命名
# train_a = traindata["x"]  # 形状: (2300, 12, 2048, 1)
# print(f"train_a 的维度是: {train_a.shape}")
# train_u = traindata["y"]  # 形状: (2300, 12, 2048, 1)
#
# # 将 x, y, context 分别取出并命名
# eval_a = evaldata["x"]  # 形状: (329, 12, 2048, 1)
# eval_u = evaldata["y"]  # 形状: (329, 12, 2048, 1)
#
# # 将 x, y, context 分别取出并命名
# test_a = testdata["x"]  # 形状: (657, 12, 2048, 1)
# test_u = testdata["y"]  # 形状: (657, 12, 2048, 1)
#
# h, w = 32, 64
# train_a = train_a.transpose(0, 1, 3, 2)  # (b,t,c,h*w)
# train_a = train_a.reshape(train_a.shape[0], train_a.shape[1], train_a.shape[2], h, w)  # (b, t, c, h, w)
# train_a = train_a[:800, 2:12, :, :, :]
#
# train_u = train_u.transpose(0, 1, 3, 2)  # (b,t,c,h*w)
# train_u = train_u.reshape(train_u.shape[0], train_u.shape[1], train_u.shape[2], h, w)  # (b, t, c, h, w)
# train_u = train_u[:800, :10, :, :, :]
#
# eval_a = eval_a.transpose(0, 1, 3, 2)  # (b,t,c,h*w)
# eval_a = eval_a.reshape(eval_a.shape[0], eval_a.shape[1], eval_a.shape[2], h, w)  # (b, t, c, h, w)
# eval_a = eval_a[:, 2:12, :, :, :]
#
# eval_u = eval_u.transpose(0, 1, 3, 2)
# eval_u = eval_u.reshape(eval_u.shape[0], eval_u.shape[1], eval_u.shape[2], h, w)  # (b, t, c, h, w)
# eval_u = eval_u[:, :10, :, :, :]
#
# test_a = test_a.transpose(0, 1, 3, 2)  # (b,t,c,h*w)
# test_a = test_a.reshape(test_a.shape[0], test_a.shape[1], test_a.shape[2], h, w)  # (b, t, c, h, w)
# test_a = test_a[:, 2:12, :, :, :]
#
# test_u = test_u.transpose(0, 1, 3, 2)  # (b,t,c,h*w)
# test_u = test_u.reshape(test_u.shape[0], test_u.shape[1], test_u.shape[2], h, w)  # (b, t, c, h, w)
# test_u = test_u[:, :10, :, :, :]
#
# dup_a = traindata["x"].transpose(0, 1, 3, 2)  # (b,t,c,h*w)
# dup_a = dup_a.reshape(dup_a.shape[0], dup_a.shape[1], dup_a.shape[2], h, w)  # (b, t, c, h, w)
# dup_a = dup_a[:200, 2:12, :, :, :]
#
# dup_u = traindata["y"].transpose(0, 1, 3, 2)  # (b,t,c,h*w)
# dup_u = dup_u.reshape(dup_u.shape[0], dup_u.shape[1], dup_u.shape[2], h, w)  # (b, t, c, h, w)
# dup_u = dup_u[:200, :10, :, :, :]
#
#
# train_a = torch.tensor(train_a, dtype=torch.float32)
# train_u = torch.tensor(train_u, dtype=torch.float32)
# eval_a = torch.tensor(eval_a, dtype=torch.float32)
# eval_u = torch.tensor(eval_u, dtype=torch.float32)
# test_a = torch.tensor(test_a, dtype=torch.float32)
# test_u = torch.tensor(test_u, dtype=torch.float32)
# dup_a = torch.tensor(dup_a, dtype=torch.float32)
# dup_u = torch.tensor(dup_u, dtype=torch.float32)
# #添加增强数据
#
#
#
#
#
# # duplicated_tensor_a = torch.cat([dup_a, dup_a, dup_a], dim=0)
# # duplicated_tensor_u = torch.cat([dup_u, dup_u, dup_u], dim=0)
# # train_a  = torch.cat((train_a, duplicated_tensor_a), dim=0)
# # train_u = torch.cat((train_u, duplicated_tensor_u), dim=0)
#
#
#
# # 加噪验证
# x = train_a[:200, :, :, :, :]
# y = train_u[:200, :, :, :, :]
# # 定义噪声参数
# num_copies = 3
# max_strength = x.std() * 0.8  # 基于数据标准差动态调整
# print("max_strength:",max_strength)
# expanded_x = x.repeat(num_copies, 1, 1, 1, 1)  # [600, 10, 1, 192, 192]
# expanded_y = y.repeat(num_copies, 1, 1, 1, 1)  # [600, 10, 1, 192, 192]
# low_ratio = 0.2
# mid_ratio = 0.5
# high_ratio = 0.8
# strengths = torch.cat([
#     torch.full((200, 1), max_strength * low_ratio),
#     torch.full((200, 1), max_strength * mid_ratio),
#     torch.full((200, 1), max_strength * high_ratio),
# ]).view(-1, 1, 1, 1, 1)
# # 添加噪声
# noisex = torch.randn_like(expanded_x)
# noisy_data_x = expanded_x + strengths * noisex
# noisy_data_x = noisy_data_x.clone().detach()
# noisey = torch.randn_like(expanded_y)
# noisy_data_y = expanded_y + strengths * noisex
# noisy_data_y = noisy_data_y.clone().detach()
#
# train_a  = torch.cat((train_a, noisy_data_x), dim=0)
# train_u = torch.cat((train_u, noisy_data_y), dim=0)
# print("Noise loaded")
#
#
# # train_a  = torch.cat((train_a, Augmented_sample), dim=0)
# # train_u = torch.cat((train_u, Augmented_target), dim=0)
#
# # 计算训练数据的均值和标准差
# mean = train_a.mean()
# std = train_a.std()
#
# # 归一化所有数据
# train_a = (train_a - mean) / std
# train_u = (train_u - mean) / std
# eval_a = (eval_a - mean) / std
# eval_u = (eval_u - mean) / std
# test_a = (test_a - mean) / std
# test_u = (test_u - mean) / std
#
# ntrain = train_a.shape[0]
# neval = eval_a.shape[0]
# ntest = test_a.shape[0]
#
# print("B1-FDS Dataset has been loaded successfully!")
# print("X train shape:", train_a.shape, "Y train shape:", train_u.shape)
# print("X eval shape:", eval_a.shape, "Y eval shape:", eval_u.shape)
# print("X test shape:", test_a.shape, "Y test shape:", test_u.shape)
#
#
#
# # 使用 DataLoader 创建数据迭代器
# train_loader2 = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(train_a, train_u), batch_size=batch_size,
#                                            shuffle=True)
# eval_loader2 = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(eval_a, eval_u), batch_size=batch_size,
#                                           shuffle=False)
# test_loader2 = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(test_a, test_u), batch_size=batch_size,
#                                           shuffle=False)
#########

# # # SEVIR
ntrain = 1000
neval = 100
ntest = 200
total = ntrain + neval + ntest
sevir_data = np.load("./dataset/SEVIR_ir069.npy")
print("dataset shape : ", sevir_data.shape)
# sevir_data = torch.tensor(sevir_data,dtype=torch.float32)

# 将数据按需加载为 PyTorch 张量，避免一次性加载
train_a = torch.tensor(sevir_data[:ntrain, :T_in, :, :, :].copy(), dtype=torch.float32)
train_u = torch.tensor(sevir_data[:ntrain, T_in:T_in+T_out, :, :, :].copy(), dtype=torch.float32)

eval_a = torch.tensor(sevir_data[ntrain:ntrain + neval, :T_in, :, :, :].copy(), dtype=torch.float32)
eval_u = torch.tensor(sevir_data[ntrain:ntrain + neval, T_in:T_in+T_out, :, :, :].copy(), dtype=torch.float32)

generate_a = torch.tensor(sevir_data[ntrain + neval:ntrain + neval+ntest, :T_in, :, :, :].copy(), dtype=torch.float32)
generate_u = torch.tensor(sevir_data[ntrain + neval:ntrain + neval+ntest, T_in:T_in + T_out, :, :, :].copy(), dtype=torch.float32)

# #加噪验证
# x = torch.tensor(sevir_data[:200, :T_in, :, :, :].copy(), dtype=torch.float32)
# y = torch.tensor(sevir_data[:200, T_in:T_in+T_out, :, :, :].copy(), dtype=torch.float32)
# # 定义噪声参数
# num_copies = 3
# max_strength = x.std() * 0.8  # 基于数据标准差动态调整
# expanded_x = x.repeat(num_copies, 1, 1, 1, 1)  # [600, 10, 1, 192, 192]
# expanded_y = y.repeat(num_copies, 1, 1, 1, 1)  # [600, 10, 1, 192, 192]
# low_ratio = 0.2
# mid_ratio = 0.5
# high_ratio = 0.8
# strengths = torch.cat([
#     torch.full((200, 1), max_strength * low_ratio),
#     torch.full((200, 1), max_strength * mid_ratio),
#     torch.full((200, 1), max_strength * high_ratio),
# ]).view(-1, 1, 1, 1, 1)
# # 添加噪声
# noisex = torch.randn_like(expanded_x)
# noisy_data_x = expanded_x + strengths * noisex
# noisy_data_x = noisy_data_x.clone().detach()
# noisey = torch.randn_like(expanded_y)
# noisy_data_y = expanded_y + strengths * noisex
# noisy_data_y = noisy_data_y.clone().detach()
#
# train_a  = torch.cat((train_a, noisy_data_x), dim=0)
# train_u = torch.cat((train_u, noisy_data_y), dim=0)
# print("Noise loaded")


#
train_a  = torch.cat((train_a, Augmented_sample), dim=0)
train_u = torch.cat((train_u, Augmented_target), dim=0)



# dup_a = torch.tensor(sevir_data[:200, :T_in, :, :, :].copy(), dtype=torch.float32)
# dup_u = torch.tensor(sevir_data[:200, T_in:T_in+T_out, :, :, :].copy(), dtype=torch.float32)
# duplicated_tensor_a = torch.cat([dup_a, dup_a, dup_a], dim=0)
# duplicated_tensor_u = torch.cat([dup_u, dup_u, dup_u], dim=0)
# train_a  = torch.cat((train_a, duplicated_tensor_a), dim=0)
# train_u = torch.cat((train_u, duplicated_tensor_u), dim=0)


# 计算训练数据的均值和标准差
mean = train_a.mean()
std = train_a.std()

# 归一化所有数据
train_a = (train_a - mean) / std
train_u = (train_u - mean) / std
eval_a = (eval_a - mean) / std
eval_u = (eval_u - mean) / std
generate_a = (generate_a - mean) / std
generate_u = (generate_u - mean) / std

print("SEVIR Dataset has been loaded successfully!")
print("X train shape:", train_a.shape, "Y train shape:", train_u.shape)
print("X eval shape:", eval_a.shape, "Y eval shape:", eval_u.shape)
print("X test shape:", generate_a.shape, "Y test shape:", generate_u.shape)

train_loader2 = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(train_a, train_u), batch_size=batch_size,
                                           shuffle=True)
eval_loader2 = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(eval_a, eval_u), batch_size=batch_size,
                                          shuffle=False)
test_loader2 = torch.utils.data.DataLoader(torch.utils.data.TensorDataset(generate_a, generate_u), batch_size=batch_size,
                                          shuffle=False)





modelbone_name = 'resnet'
mode ="toview"
# modelbone = Afno_net(img_size=[32,64], patch_size=8, in_channels=1, out_channels=1,embed_dim=768 , depth=12).to(device)
# modelbone = VisionTransformer(img_size=[192,192], patch_size=8, in_c=1, out_chans=1,embed_dim=384, depth=3,num_heads=6).to(device)
# modelbone = FNO2d4fds(modes1 = 12, modes2 = 12,pred_len=10, out_channel= 10,width = 20).to(device)
# modelbone =  U_net4fds(input_channels = 10, output_channels = 10, kernel_size = 3, dropout_rate = 0.1).to(device)
# modelbone = CLSTM4fds(input_size=(192, 192), channels=1, pred_len=10, hidden_dim=[64], num_layers=1).to(device)
# modelbone = UNO4fds(in_width=14, width=32,output_channel=10).to(device)
# modelbone = CNO4fds(in_size=32, N_layers=1, in_dim=10,out_dim=10).to(device)
modelbone = ResNet4fds(input_channels = 10, output_channels = 10, kernel_size = 3).to(device)


def train2(modelbone, loader, optimizer, criterion,batch_size):
    modelbone.train()
    total_loss = 0

    for inputs, targets in loader:
        inputs, targets = inputs.to(device), targets.to(device)

        optimizer.zero_grad()
        outputs = modelbone(inputs)
        loss = MSE_loss(outputs, targets)

        loss.backward()
        optimizer.step()


        total_loss += loss.item()

    return total_loss / len(loader) # Return average loss per sample


# Updated evaluation function
def evaluate2(modelbone, loader, criterion,num,batch_size):
    modelbone.eval()
    total_loss = 0
    num_batches2 = 0  # Counter to track number of batches
    with torch.no_grad():
        for inputs, targets in loader:
            inputs, targets = inputs.to(device), targets.to(device)

            outputs = modelbone(inputs)
            loss = MSE_loss(outputs, targets)

            total_loss += loss.item()

    return total_loss / len(loader) # Return average loss per sample

def test2(modelbone, loader, criterion,num,batch_size):
    modelbone.eval()
    total_loss = 0
    num_batches2 = 0  # Counter to track number of batches
    with torch.no_grad():
        for inputs, targets in loader:
            inputs, targets = inputs.to(device), targets.to(device)
            original_xx = inputs.cpu().numpy()
            outputs = modelbone(inputs)
            loss = MSE_loss(outputs, targets)

            total_loss += loss.item()

            inputs_list.append(original_xx)
            trues_list.append(targets.cpu().numpy())
            preds_list.append(outputs.cpu().numpy())
    return total_loss / len(loader) # Return average loss per sample
def test3(modelbone, loader, criterion, num, batch_size):
    modelbone.eval()
    total_loss_mse = 0  # 累计MSE损失
    total_loss_mae = 0  # 累计MAE损失
    ssim_sum = 0  # 累计SSIM值
    psnr_sum = 0  # 累计PSNR值
    num_batches2 = 0  # Counter to track number of batches
    with torch.no_grad():
        for inputs, targets in loader:
            inputs, targets = inputs.to(device), targets.to(device)
            original_xx = inputs.cpu().numpy()
            outputs = modelbone(inputs)

            # 计算MSE损失
            loss_mse = criterion(outputs, targets)
            total_loss_mse += loss_mse.item()

            # 计算MAE损失
            loss_mae = torch.nn.L1Loss()(outputs, targets)
            total_loss_mae += loss_mae.item()

            # 将数据范围从[-1, 1]转换到[0, 1]，以适合后续SSIM和PSNR计算的要求
            inputs = (inputs + 1) / 2
            outputs = (outputs + 1) / 2
            targets = (targets + 1) / 2

            # 确保数据类型为合适的浮点型，这里转换为torch.float32
            inputs = inputs.type(torch.float32)
            outputs = outputs.type(torch.float32)
            targets = targets.type(torch.float32)

            inputs2 = inputs.reshape(-1, 1, 64, 64)
            outputs2 = outputs.reshape(-1, 1, 64, 64)
            targets2 = targets.reshape(-1, 1, 64, 64)

            ssim_loss = 1 - ssim(outputs2,targets2, data_range=1, size_average=True)  # return a scalar
            ssim_sum += ssim_loss.item()


            # 计算PSNR
            mse_for_psnr = torch.nn.functional.mse_loss(outputs, targets)
            psnr_value = 10 * torch.log10((1.0 ** 2) / mse_for_psnr)  # 数据范围是[0, 1]，MAX_I为1
            psnr_sum += psnr_value.item()

            inputs_list.append(original_xx)
            trues_list.append(targets.cpu().numpy())
            preds_list.append(outputs.cpu().numpy())

            num_batches2 += 1

    # 计算平均的各项指标
    mse_avg = total_loss_mse / num_batches2
    mae_avg = total_loss_mae / num_batches2
    ssim_avg = ssim_sum / num_batches2
    psnr_avg = psnr_sum / num_batches2

    return mse_avg, ssim_avg, mae_avg, psnr_avg

# Training loop
num_epochs = 120
min_loss =100000
currentepoch = 0
learning_rate = 0.001
scheduler_step = 25
# 定义学习率调度器的步长为 100 次。每经过 scheduler_step 次训练后，学习率将按照 scheduler_gamma 设置进行调整。
scheduler_gamma = 0.5
# 设置学习率调度器的衰减因子为 0.5。每 scheduler_step 次训练后，学习率将乘以这个因子。
# Define optimizer and loss function
optimizer = Adam(modelbone.parameters(), lr=learning_rate, weight_decay=1e-4)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=scheduler_step, gamma=scheduler_gamma)
save_path = f'./ckpt/{modelbone_name}_best_epoch_aftervq_top{top_k_numset}_{task}_{mode}.pth'
print("modelbone:",modelbone_name)
print("mode:",mode)
for epoch in tqdm(range(num_epochs), desc="Processing epoch"):
    t1 = default_timer()
    train_loss = train2(modelbone, train_loader2, optimizer, criterion,batch_size)
    val_loss = evaluate2(modelbone, eval_loader2, criterion,neval,batch_size)
    if train_loss< min_loss:
        min_loss = train_loss
        currentepoch = epoch
        torch.save(modelbone.state_dict(), save_path)
    scheduler.step()
    t2 = default_timer()
    time = t2-t1
    print(f'Epoch {epoch + 1}/{num_epochs}, Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}')
    # print(f'Epoch {epoch+1 }/{num_epochs} , Time Consuming:{time:.4f}s')


print("第：",currentepoch+1," 个周期训练参数被加载至测试集")
best_check = torch.load(save_path, weights_only=True)
if 'state_dict' in best_check:
    modelbone.load_state_dict(best_check['state_dict'])
    print("最佳参数已加载1")
else:
    # 如果保存的是直接的模型权重而不是字典
    modelbone.load_state_dict(best_check)
    print("最佳参数已加载2")
#

inputs_list = []
trues_list = []
preds_list = []

# Evaluate on test set
mse_loss, ssim_avg, mae_avg, psnr_avg= test3(modelbone, test_loader2, criterion,ntest,batch_size)
rmse = np.sqrt(mse_loss)
print(f'Test RMSE: {rmse:.4f}')
print(f'Test MAE: {mae_avg:.4f}')
print(f'Test SSIM: {ssim_avg:.4f}')
print(f'Test PSNR: {psnr_avg:.4f}')


inputs_array = np.concatenate(inputs_list, axis=0)
trues_array = np.concatenate(trues_list, axis=0)
preds_array = np.concatenate(preds_list, axis=0)


base_path = f'./result/{modelbone_name}_{task}_top{top_k_numset}_after_{mode}_'
inputs_path = base_path + 'inputs.npy'
trues_path = base_path + 'trues.npy'
preds_path = base_path + 'preds.npy'

np.save(inputs_path, inputs_array)
np.save(trues_path, trues_array)
np.save(preds_path, preds_array)
print("输入输出及预测结果已保存")


# InputTestdata = np.load(inputs_path)
# print(f"输入数据的维度是: {InputTestdata.shape}")
# TrueTestdata = np.load(trues_path)
# print(f"真实输出数据的维度是: {TrueTestdata.shape}")
# OutputTestdata = np.load(preds_path)
# print(f"预测输出数据的维度是: {OutputTestdata.shape}")
#