import torch
import logging
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
import numpy as np
from torch.utils.data import DataLoader, TensorDataset, ConcatDataset
import scipy.io
import torch.utils.data
import os
import random
import torch
import numpy as np
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import torch.utils.data as data
import torch.distributed as dist
import torch.multiprocessing as mp
# import netCDF4 as nc
import torchvision.transforms as transforms
from tqdm import tqdm
import logging
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import torch.utils.data as data

# Setup logging
backbone = 'beam05res_0804'

logging.basicConfig(filename=f'{backbone}_training_log.log', level=logging.INFO,
                    format='%(asctime)s %(message)s')

# Set a specific seed
seed = 42


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


set_seed(seed)


class VectorQuantizerEMA(nn.Module):
    def __init__(self, num_embeddings, embedding_dim, commitment_cost, decay=0.99, epsilon=1e-5, top_k=3):
        super(VectorQuantizerEMA, self).__init__()

        self._embedding_dim = embedding_dim
        self._num_embeddings = num_embeddings
        self._top_k = top_k

        self._embedding = nn.Embedding(self._num_embeddings, self._embedding_dim)
        self._embedding.weight.data.normal_()
        self._commitment_cost = commitment_cost

        self.register_buffer('_ema_cluster_size', torch.zeros(num_embeddings))
        self._ema_w = nn.Parameter(torch.Tensor(num_embeddings, self._embedding_dim))
        self._ema_w.data.normal_()

        self._decay = decay
        self._epsilon = epsilon

    def forward(self, inputs):
        inputs = inputs.permute(0, 2, 3, 1).contiguous()
        input_shape = inputs.shape
        flat_input = inputs.view(-1, self._embedding_dim)

        distances = (torch.sum(flat_input ** 2, dim=1, keepdim=True)
                     + torch.sum(self._embedding.weight ** 2, dim=1)
                     - 2 * torch.matmul(flat_input, self._embedding.weight.t()))

        top_k_indices = torch.topk(distances, self._top_k, dim=1, largest=False)[1]
        top_k_encodings = []
        top_k_quantized = []
        for i in range(self._top_k):
            encoding_indices = top_k_indices[:, i].unsqueeze(1)
            encodings = torch.zeros(encoding_indices.shape[0], self._num_embeddings, device=inputs.device)
            encodings.scatter_(1, encoding_indices, 1)
            top_k_encodings.append(encodings)

            quantized = torch.matmul(encodings, self._embedding.weight).view(input_shape)
            top_k_quantized.append(quantized)

        if self.training:
            self._ema_cluster_size = self._ema_cluster_size * self._decay + \
                                     (1 - self._decay) * torch.sum(encodings, 0)

            n = torch.sum(self._ema_cluster_size.data)
            self._ema_cluster_size = (
                    (self._ema_cluster_size + self._epsilon)
                    / (n + self._num_embeddings * self._epsilon) * n)

            dw = torch.matmul(encodings.t(), flat_input)
            self._ema_w = nn.Parameter(self._ema_w * self._decay + (1 - self._decay) * dw)

            self._embedding.weight = nn.Parameter(self._ema_w / self._ema_cluster_size.unsqueeze(1))

        e_latent_loss = F.mse_loss(top_k_quantized[0].detach(), inputs)
        loss = self._commitment_cost * e_latent_loss

        quantized = inputs + (top_k_quantized[0] - inputs).detach()
        top_k_quantized = [inputs + (q - inputs).detach() for q in top_k_quantized]

        avg_probs = torch.mean(encodings, dim=0)
        perplexity = torch.exp(-torch.sum(avg_probs * torch.log(avg_probs + 1e-10)))

        return loss, quantized.permute(0, 3, 1, 2).contiguous(), perplexity, encodings, top_k_quantized

    def lookup(self, x):
        embeddings = F.embedding(x, self._embedding)
        return embeddings


class Residual(nn.Module):
    def __init__(self, in_channels, num_hiddens, num_residual_hiddens):
        super(Residual, self).__init__()
        self._block = nn.Sequential(
            nn.ReLU(True),
            nn.Conv2d(in_channels=in_channels,
                      out_channels=num_residual_hiddens,
                      kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(num_residual_hiddens),
            nn.ReLU(True),
            nn.Conv2d(in_channels=num_residual_hiddens,
                      out_channels=num_hiddens,
                      kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(num_hiddens)
        )

    def forward(self, x):
        return x + self._block(x)


class ResidualStack(nn.Module):
    def __init__(self, in_channels, num_hiddens, num_residual_layers, num_residual_hiddens):
        super(ResidualStack, self).__init__()
        self._num_residual_layers = num_residual_layers
        self._layers = nn.ModuleList([Residual(in_channels, num_hiddens, num_residual_hiddens)
                                      for _ in range(self._num_residual_layers)])

    def forward(self, x):
        for i in range(self._num_residual_layers):
            x = self._layers[i](x)
        return F.relu(x)


class Projection(nn.Module):
    def __init__(self, in_channels, num_hiddens, num_residual_layers, num_residual_hiddens):
        super(Projection, self).__init__()

        self._conv_1 = nn.Conv2d(in_channels=in_channels,
                                 out_channels=num_hiddens // 2,
                                 kernel_size=4,
                                 stride=2,
                                 padding=1)

        self._conv_2 = nn.Conv2d(in_channels=num_hiddens // 2,
                                 out_channels=num_hiddens,
                                 kernel_size=4,
                                 stride=2,
                                 padding=1)

        self._conv_3 = nn.Conv2d(in_channels=num_hiddens,
                                 out_channels=num_hiddens,
                                 kernel_size=3,
                                 stride=1, padding=1)

        self._residual_stack = ResidualStack(in_channels=num_hiddens,
                                             num_hiddens=num_hiddens,
                                             num_residual_layers=num_residual_layers,
                                             num_residual_hiddens=num_residual_hiddens)

    def forward(self, inputs):
        x = self._conv_1(inputs)
        x = F.relu(x)
        x = self._conv_2(x)
        x = F.relu(x)
        x = self._conv_3(x)
        return self._residual_stack(x)


class Decoder(nn.Module):
    def __init__(self, in_channels, num_hiddens, num_residual_layers, num_residual_hiddens, out_channels):
        super(Decoder, self).__init__()

        self._conv_1 = nn.Conv2d(in_channels=in_channels,
                                 out_channels=num_hiddens,
                                 kernel_size=3,
                                 stride=1, padding=1)

        self._residual_stack = ResidualStack(in_channels=num_hiddens,
                                             num_hiddens=num_hiddens,
                                             num_residual_layers=num_residual_layers,
                                             num_residual_hiddens=num_residual_hiddens)

        self._conv_trans_1 = nn.ConvTranspose2d(in_channels=num_hiddens,
                                                out_channels=num_hiddens // 2,
                                                kernel_size=4,
                                                stride=2, padding=1)

        self._conv_trans_2 = nn.ConvTranspose2d(in_channels=num_hiddens // 2,
                                                out_channels=out_channels,
                                                kernel_size=4,
                                                stride=2, padding=1)

    def forward(self, inputs):
        x = self._conv_1(inputs)
        x = self._residual_stack(x)
        x = self._conv_trans_1(x)
        x = F.relu(x)
        return self._conv_trans_2(x)


class BeamVQ_module(nn.Module):
    def __init__(self,
                 in_channel=1,
                 num_hiddens=128,
                 res_layers=2,
                 res_units=32,
                 embedding_nums=1024,  # K
                 embedding_dim=128,  # D
                 top_k=1,
                 commitment_cost=0.25,
                 decay=0.99):
        super(BeamVQ_module, self).__init__()
        self.in_channel = in_channel
        self.num_hiddens = num_hiddens
        self.res_layers = res_layers
        self.res_units = res_units
        self.embedding_dim = embedding_dim
        self.embedding_nums = embedding_nums
        self.top_k = top_k
        self.decay = decay
        self.commitment_cost = commitment_cost
        self._projection = Projection(in_channel, num_hiddens,
                                      res_layers, res_units)
        self._pre_vq_conv = nn.Conv2d(in_channels=num_hiddens,
                                      out_channels=embedding_dim,
                                      kernel_size=1,
                                      stride=1)
        # code book
        self._vq_vae = VectorQuantizerEMA(num_embeddings=self.embedding_nums,
                                          embedding_dim=self.embedding_dim,
                                          commitment_cost=self.commitment_cost,
                                          decay=self.decay,
                                          top_k=self.top_k)

        self._decoder = Decoder(in_channels=self.embedding_dim,
                                num_hiddens=self.num_hiddens,
                                num_residual_layers=self.res_layers,
                                num_residual_hiddens=self.res_units,
                                out_channels=self.in_channel)

    def forward(self, x):
        '''
        Process input x through a neural network model.
        The shape of the input is [B, C, W, H], i.e. [batch size, number of channels, width, height].
        The input x is projected into the hidden unit space by means of the _projection function and the output has the shape [B, hidden_units, W//4, H//4].
        Convolution is then performed before applying VQ-VAE, and z is transformed into coded form.
        After VQ-VAE processing, the output consists of the loss, quantized encoding, perplexity, and other possible outputs (ignored here with _).
        The quantized code is reconstructed from the original input x by the decoder.
        The return value consists of the loss, the reconstructed x, and the perplexity.
        quantized -> embedding, quantized is equivalent to the encoder output in videoGPT.
        '''
        z = self._projection(x)
        z = self._pre_vq_conv(z)
        loss, quantized, perplexity, _ = self._vq_vae(z)
        x_recon = self._decoder(quantized)
        return loss, x_recon, perplexity

    def get_embedding(self, x):
        return self._pre_vq_conv(self._encoder(x))

    def get_quantization(self, x):
        z = self._encoder(x)
        z = self._pre_vq_conv(z)
        _, quantized, _, _ = self._vq_vae(z)
        return quantized

    def reconstruct_img_by_embedding(self, embedding):
        loss, quantized, perplexity, _, quantized_list = self._vq_vae(embedding)
        return self._decoder(quantized)

    def reconstruct_img(self, q):
        return self._decoder(q)

    @property
    def pre_vq_conv(self):
        return self._pre_vq_conv

    @property
    def encoder(self):
        return self._encoder


class BeamVQ(nn.Module):
    def __init__(self,
                 in_channel=1,
                 res_units=64,
                 res_layers=1,
                 embedding_nums=1024,
                 embedding_dim=512,
                 top_k=2,
                 complete=True,
                 t_in = 10,
                 ):
        super(BeamVQ, self).__init__()
        self.complete = complete
        self.BV_module = BeamVQ_module(in_channel=in_channel,
                                       res_units=res_units,
                                       res_layers=res_layers,
                                       embedding_dim=embedding_dim,
                                       embedding_nums=embedding_nums,
                                       top_k=top_k)
        self.t_in = t_in
        self.embedding_dim = embedding_dim
        # self.lambdaVector = lambdaVector

        # 定义MLP层
        self.mlp = nn.Sequential(
            nn.Linear(embedding_dim, embedding_dim),  # 将 [b, 32, 512] 展平后输入
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(embedding_dim, embedding_dim)
        )
        # #物理形参的mlp
        # self.mlp2 = nn.Sequential(
        #
        # )

    def forward(self, input_frames,Vectors):
        encoder_embed = self.BV_module._projection(input_frames)
        z = self.BV_module._pre_vq_conv(encoder_embed)

        B_T,C,H,W = z.shape
        # print("z.shape,before:",z.shape)
        z = z.view(-1, self.t_in,C,H,W)

        # 对Vectors进行MLP处理
        Vectors = self.mlp(Vectors)
        Vectors = Vectors.unsqueeze(1).unsqueeze(-1).unsqueeze(-1)# [8,1,512,1,1]
        # print("Vector.shape:",Vectors.shape)
        z = Vectors*z
        z = z.view(B_T,C,H,W)

        # print("z.shape,after:", z.shape)
        vq_loss, Latent_embed, _, _, Latent_embed_list = self.BV_module._vq_vae(z)
        pred = self.BV_module._decoder(Latent_embed)

        # ================generate many prediction features===============

        top_k_features = []
        for quantized_top_k in Latent_embed_list:
            quantized_top_k = quantized_top_k.permute(0, 3, 1, 2)
            predicti_feature_k = self.BV_module._decoder(quantized_top_k)
            top_k_features.append(predicti_feature_k)
        return pred, top_k_features, vq_loss

if __name__ == "__main__":
    input_tensor = torch.rand(80, 1, 64, 64)  # b*10 1 64 64

    # PAGE
    # input_tensor = upstream_mask(input_tensor)

    # channel_weights = channel_conv_module(input_parameters = a, boundary = b)
    # input_tensor_physical = input_tensor * channel_weights

    input_tensor_physical = torch.rand(80, 1, 64, 64)
    vectors = torch.rand(8, 512)
    model = BeamVQ()
    pred, top_k_features, vq_loss = model(input_tensor_physical,vectors)
    print(pred.shape, len(top_k_features), vq_loss)
    print("生成数据的维度：", top_k_features[0].shape)
    # pred 作为top1，插入第一位
    top_k_features.insert(0, pred)
    print(len(top_k_features))